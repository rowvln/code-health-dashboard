export default function FileTable({ files }) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>File</th>
            <th>Score</th>
            <th>Issues</th>
            <th>Complexity</th>
          </tr>
        </thead>
        <tbody>
          {files.map((file) => (
            <tr key={file.name}>
              <td>{file.name}</td>
              <td>{file.score}</td>
              <td>{file.issues}</td>
              <td>{file.complexity}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
