export default function ScoreCard({ title, value, description }) {
  return (
    <section className="panel score-card">
      <p className="card-label">{title}</p>
      <h2>{value}</h2>
      <p className="card-description">{description}</p>
    </section>
  )
}
