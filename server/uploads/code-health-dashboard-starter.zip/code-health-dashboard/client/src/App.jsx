import { useState } from 'react'
import UploadForm from './components/UploadForm'
import ScoreCard from './components/ScoreCard'
import FileTable from './components/FileTable'
import RecommendationList from './components/RecommendationList'
import { analyzeFile } from './services/api'

const initialResults = null

export default function App() {
  const [results, setResults] = useState(initialResults)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  async function handleAnalyze(file) {
    setLoading(true)
    setError('')

    try {
      const data = await analyzeFile(file)
      setResults(data)
    } catch (err) {
      setError(err.message || 'Something went wrong while analyzing the file.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="app-shell">
      <header className="hero">
        <p className="eyebrow">Portfolio MVP</p>
        <h1>Code Health Dashboard</h1>
        <p className="subtitle">
          Translate code quality signals into simple insights that both technical and non-technical users can understand.
        </p>
      </header>

      <UploadForm onAnalyze={handleAnalyze} loading={loading} />

      {error && <div className="error-banner">{error}</div>}

      {results && (
        <main className="dashboard-grid">
          <ScoreCard title="Code Health Score" value={results.score} description="Overall score based on lint findings and complexity." />
          <ScoreCard title="Total Issues" value={results.summary.issues} description="Combined findings across all analyzed files." />
          <ScoreCard title="High Severity" value={results.summary.high_severity} description="Fatal and error-level findings that may need immediate attention." />
          <ScoreCard title="Files Analyzed" value={results.summary.files_analyzed} description="Total Python files included in this scan." />

          <section className="panel panel-wide">
            <h2>File Breakdown</h2>
            <FileTable files={results.files} />
          </section>

          <section className="panel panel-wide">
            <h2>Top Recommendations</h2>
            <RecommendationList recommendations={results.recommendations} />
          </section>
        </main>
      )}
    </div>
  )
}
