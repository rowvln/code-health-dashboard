# Code Health Dashboard

Code Health Dashboard is a full-stack web application that analyzes source code and translates technical quality signals into clear, actionable insights for both developers and non-technical stakeholders.

## Overview
This project is designed to bridge the gap between engineering metrics and product visibility. Instead of showing only raw linting output, it presents a code health score, issue summaries, file-level breakdowns, and recommended next steps in a simple dashboard.

## Problem
Many code quality tools are built primarily for engineers and can be difficult for non-technical stakeholders to interpret. This project aims to make code quality easier to understand without losing technical value.

## Target Users
- Developers
- Student engineers
- Product managers
- Engineering managers

## MVP Features
- Upload a Python file or zipped Python project
- Run static analysis with Pylint and Radon
- Generate a code health score
- View flagged issues by file
- Show top recommended fixes

## Future Features
- GitHub repo integration
- AI-generated refactoring suggestions
- Trend tracking across scans
- Complexity hotspot heatmap
- Multi-language support

## Tech Stack
- Frontend: React + Vite
- Backend: Flask
- Analysis Engine: Pylint + Radon
- Styling: Plain CSS

## Project Structure
```text
code-health-dashboard/
├── client/
├── server/
├── docs/
└── README.md
```

## Local Setup
### Backend
```bash
cd server
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python run.py
```

### Frontend
```bash
cd client
npm install
npm run dev
```

## Example Workflow
1. Upload a Python file or zip archive.
2. The backend saves and analyzes the upload.
3. The API returns a score, summary, file breakdown, and recommendations.
4. The frontend displays the results in a dashboard.

## Roadmap
See the `docs/` folder for roadmap, user stories, MVP scope, wireframes, and API spec.

## Lessons Learned
This starter version is focused on proving the product concept quickly. The next iterations should improve parsing accuracy, expand analysis depth, and refine how technical findings are translated for non-technical users.
