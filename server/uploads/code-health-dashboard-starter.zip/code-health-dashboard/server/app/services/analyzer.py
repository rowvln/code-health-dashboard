from __future__ import annotations

import json
import shutil
import subprocess
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory
from .scoring import build_score_payload


def analyze_path(file_path: Path) -> dict:
    if file_path.suffix.lower() == ".zip":
        return _analyze_zip(file_path)
    return _analyze_python_files([file_path])


def _analyze_zip(zip_path: Path) -> dict:
    with TemporaryDirectory() as temp_dir:
        extract_dir = Path(temp_dir) / "extracted"
        extract_dir.mkdir(parents=True, exist_ok=True)

        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(extract_dir)

        python_files = list(extract_dir.rglob("*.py"))
        return _analyze_python_files(python_files)


def _run_pylint(file_path: Path) -> dict:
    command = [
        shutil.which("pylint") or "pylint",
        str(file_path),
        "--output-format=json",
        "--score=n",
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=False)

    if not completed.stdout.strip():
        return {"issues": []}

    try:
        issues = json.loads(completed.stdout)
    except json.JSONDecodeError:
        issues = []

    return {"issues": issues}


def _run_radon(file_path: Path) -> dict:
    command = [
        shutil.which("radon") or "radon",
        "cc",
        str(file_path),
        "-j",
    ]
    completed = subprocess.run(command, capture_output=True, text=True, check=False)

    if not completed.stdout.strip():
        return {"complexity": 0}

    try:
        data = json.loads(completed.stdout)
        entries = data.get(str(file_path), [])
        max_complexity = max((entry.get("complexity", 0) for entry in entries), default=0)
    except json.JSONDecodeError:
        max_complexity = 0

    return {"complexity": max_complexity}


def _analyze_python_files(files: list[Path]) -> dict:
    file_results = []

    for file_path in files:
        pylint_result = _run_pylint(file_path)
        radon_result = _run_radon(file_path)
        file_results.append(
            {
                "name": file_path.name,
                "issues": pylint_result["issues"],
                "complexity": radon_result["complexity"],
            }
        )

    return build_score_payload(file_results)
