from __future__ import annotations

from collections import Counter

SEVERITY_WEIGHTS = {
    "fatal": 10,
    "error": 8,
    "warning": 5,
    "refactor": 3,
    "convention": 1,
    "info": 0,
}


def score_file(issue_types: list[str], complexity: int) -> int:
    score = 100
    score -= sum(SEVERITY_WEIGHTS.get(issue_type, 1) for issue_type in issue_types)

    if complexity >= 20:
        score -= 15
    elif complexity >= 10:
        score -= 8
    elif complexity >= 5:
        score -= 3

    return max(score, 0)


def build_recommendations(file_payloads: list[dict]) -> list[str]:
    recommendations = []
    sorted_files = sorted(file_payloads, key=lambda item: item["score"])

    for file_data in sorted_files[:3]:
        if file_data["complexity"] >= 10:
            recommendations.append(
                f"Refactor high-complexity logic in {file_data['name']} (complexity {file_data['complexity']})."
            )
        elif file_data["issue_count"] > 0:
            recommendations.append(
                f"Address the highest-severity lint issues in {file_data['name']} ({file_data['issue_count']} findings)."
            )

    if not recommendations:
        recommendations.append("No major issues detected. Consider adding trend tracking as the next improvement.")

    return recommendations


def build_score_payload(file_results: list[dict]) -> dict:
    payload_files = []
    severity_counter = Counter()

    for file_result in file_results:
        issue_types = [issue.get("type", "info") for issue in file_result["issues"]]
        severity_counter.update(issue_types)
        file_score = score_file(issue_types, file_result["complexity"])

        payload_files.append(
            {
                "name": file_result["name"],
                "score": file_score,
                "issues": len(file_result["issues"]),
                "complexity": file_result["complexity"],
            }
        )

    overall_score = round(sum(item["score"] for item in payload_files) / len(payload_files), 0) if payload_files else 100

    recommendation_input = [
        {
            "name": item["name"],
            "score": item["score"],
            "issue_count": item["issues"],
            "complexity": item["complexity"],
        }
        for item in payload_files
    ]

    return {
        "score": int(overall_score),
        "summary": {
            "issues": sum(item["issues"] for item in payload_files),
            "high_severity": severity_counter.get("fatal", 0) + severity_counter.get("error", 0),
            "files_analyzed": len(payload_files),
        },
        "files": payload_files,
        "recommendations": build_recommendations(recommendation_input),
    }
